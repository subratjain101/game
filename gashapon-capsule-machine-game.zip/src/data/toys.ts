export type Rarity = 'common' | 'uncommon' | 'rare' | 'epic' | 'legendary';

export interface Toy {
  id: string;
  name: string;
  emoji: string;
  rarity: Rarity;
  description: string;
  capsuleColor: string;
  capColor: string;
}

export const RARITY_CONFIG: Record<Rarity, {
  label: string;
  color: string;
  bgColor: string;
  borderColor: string;
  glowColor: string;
  sparkleColor: string;
  weight: number;
  stars: number;
}> = {
  common: {
    label: 'Common',
    color: '#9ca3af',
    bgColor: 'bg-gray-100',
    borderColor: 'border-gray-300',
    glowColor: 'shadow-gray-300',
    sparkleColor: '#d1d5db',
    weight: 50,
    stars: 1,
  },
  uncommon: {
    label: 'Uncommon',
    color: '#4ade80',
    bgColor: 'bg-green-50',
    borderColor: 'border-green-300',
    glowColor: 'shadow-green-300',
    sparkleColor: '#86efac',
    weight: 30,
    stars: 2,
  },
  rare: {
    label: 'Rare',
    color: '#60a5fa',
    bgColor: 'bg-blue-50',
    borderColor: 'border-blue-400',
    glowColor: 'shadow-blue-400',
    sparkleColor: '#93c5fd',
    weight: 15,
    stars: 3,
  },
  epic: {
    label: 'Epic',
    color: '#c084fc',
    bgColor: 'bg-purple-50',
    borderColor: 'border-purple-400',
    glowColor: 'shadow-purple-400',
    sparkleColor: '#d8b4fe',
    weight: 4,
    stars: 4,
  },
  legendary: {
    label: 'Legendary',
    color: '#fbbf24',
    bgColor: 'bg-yellow-50',
    borderColor: 'border-yellow-400',
    glowColor: 'shadow-yellow-400',
    sparkleColor: '#fde68a',
    weight: 1,
    stars: 5,
  },
};

export const ALL_TOYS: Toy[] = [
  // Common
  { id: 'shiba', name: 'Shiba Inu', emoji: '🐕', rarity: 'common', description: 'A fluffy Shiba puppy figurine.', capsuleColor: '#f97316', capColor: '#fb923c' },
  { id: 'frog', name: 'Leap Frog', emoji: '🐸', rarity: 'common', description: 'A cheerful green frog on a lily pad.', capsuleColor: '#22c55e', capColor: '#4ade80' },
  { id: 'duck', name: 'Rubber Ducky', emoji: '🐥', rarity: 'common', description: 'The classic bath-time companion.', capsuleColor: '#eab308', capColor: '#facc15' },
  { id: 'bear', name: 'Mini Bear', emoji: '🐻', rarity: 'common', description: 'A cozy little bear hugging a honey pot.', capsuleColor: '#a16207', capColor: '#ca8a04' },
  { id: 'cat', name: 'Lucky Cat', emoji: '🐱', rarity: 'common', description: 'A waving maneki-neko cat.', capsuleColor: '#ec4899', capColor: '#f472b6' },
  { id: 'star', name: 'Shooting Star', emoji: '⭐', rarity: 'common', description: 'A tiny glittery star charm.', capsuleColor: '#6366f1', capColor: '#818cf8' },

  // Uncommon
  { id: 'fox', name: 'Cosmic Fox', emoji: '🦊', rarity: 'uncommon', description: 'A galaxy-patterned fox figurine.', capsuleColor: '#f97316', capColor: '#fb923c' },
  { id: 'penguin', name: 'Ice Penguin', emoji: '🐧', rarity: 'uncommon', description: 'A stylish penguin in a tiny tuxedo.', capsuleColor: '#0ea5e9', capColor: '#38bdf8' },
  { id: 'bunny', name: 'Moon Bunny', emoji: '🐰', rarity: 'uncommon', description: 'A lunar rabbit making mochi.', capsuleColor: '#e879f9', capColor: '#f0abfc' },
  { id: 'panda', name: 'Panda Chef', emoji: '🐼', rarity: 'uncommon', description: 'A panda stirring a bowl of ramen.', capsuleColor: '#000000', capColor: '#374151' },
  { id: 'turtle', name: 'Ninja Turtle', emoji: '🐢', rarity: 'uncommon', description: 'A tiny turtle doing a karate pose.', capsuleColor: '#16a34a', capColor: '#22c55e' },

  // Rare
  { id: 'unicorn', name: 'Unicorn', emoji: '🦄', rarity: 'rare', description: 'A shimmering unicorn with rainbow mane.', capsuleColor: '#db2777', capColor: '#ec4899' },
  { id: 'dragon', name: 'Baby Dragon', emoji: '🐲', rarity: 'rare', description: 'A tiny dragon hatching from an egg.', capsuleColor: '#dc2626', capColor: '#ef4444' },
  { id: 'robot', name: 'Retro Robot', emoji: '🤖', rarity: 'rare', description: 'A vintage-style toy robot.', capsuleColor: '#475569', capColor: '#64748b' },
  { id: 'mermaid', name: 'Mermaid', emoji: '🧜', rarity: 'rare', description: 'A glittery mermaid with a pearlescent tail.', capsuleColor: '#0891b2', capColor: '#06b6d4' },

  // Epic
  { id: 'phoenix', name: 'Phoenix', emoji: '🔥', rarity: 'epic', description: 'A blazing phoenix rising from ashes.', capsuleColor: '#ea580c', capColor: '#f97316' },
  { id: 'kirin', name: 'Kirin', emoji: '✨', rarity: 'epic', description: 'A mythical Kirin with golden scales.', capsuleColor: '#d97706', capColor: '#f59e0b' },
  { id: 'wizard', name: 'Wizard Cat', emoji: '🧙', rarity: 'epic', description: 'A cat wearing a starry wizard hat.', capsuleColor: '#7c3aed', capColor: '#8b5cf6' },

  // Legendary
  { id: 'galaxy', name: 'Galaxy Spirit', emoji: '🌌', rarity: 'legendary', description: 'A cosmic entity made of stardust.', capsuleColor: '#4f46e5', capColor: '#6366f1' },
  { id: 'golden-cat', name: 'Golden Neko', emoji: '🏆', rarity: 'legendary', description: 'An ultra-rare solid gold lucky cat.', capsuleColor: '#b45309', capColor: '#d97706' },
];

export const STARTER_COLLECTION: string[] = ['shiba', 'duck', 'frog'];

export function rollToy(): Toy {
  const totalWeight = Object.values(RARITY_CONFIG).reduce((sum, r) => sum + r.weight, 0);
  let random = Math.random() * totalWeight;
  
  let selectedRarity: Rarity = 'common';
  for (const [rarity, config] of Object.entries(RARITY_CONFIG)) {
    random -= config.weight;
    if (random <= 0) {
      selectedRarity = rarity as Rarity;
      break;
    }
  }

  const pool = ALL_TOYS.filter(t => t.rarity === selectedRarity);
  return pool[Math.floor(Math.random() * pool.length)];
}
