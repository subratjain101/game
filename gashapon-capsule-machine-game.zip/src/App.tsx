import React, { useState, useEffect } from 'react';
import GashaponMachine from './components/GashaponMachine';
import CollectibleShelf from './components/CollectibleShelf';
import CoinShop from './components/CoinShop';
import Confetti from './components/Confetti';
import { Toy, ALL_TOYS, STARTER_COLLECTION, RARITY_CONFIG } from './data/toys';

const INITIAL_COINS = 5;

const FloatingCoin: React.FC<{ id: number; onDone: (id: number) => void }> = ({ id, onDone }) => {
  useEffect(() => {
    const t = setTimeout(() => onDone(id), 1000);
    return () => clearTimeout(t);
  }, [id, onDone]);

  return (
    <div
      className="fixed pointer-events-none z-50 text-2xl"
      style={{
        left: `${30 + Math.random() * 40}%`,
        top: '40%',
        animation: 'float-up 1s ease-out forwards',
      }}
    >
      🪙
    </div>
  );
};

export default function App() {
  // Load from localStorage or use defaults
  const [collected, setCollected] = useState<Toy[]>(() => {
    try {
      const saved = localStorage.getItem('gashapon_collected');
      if (saved) return JSON.parse(saved);
    } catch {}
    // Starter collection
    return STARTER_COLLECTION.map((id) => ALL_TOYS.find((t) => t.id === id)!).filter(Boolean);
  });

  const [coins, setCoins] = useState<number>(() => {
    try {
      const saved = localStorage.getItem('gashapon_coins');
      if (saved) return Number(saved);
    } catch {}
    return INITIAL_COINS;
  });

  const [activeTab, setActiveTab] = useState<'machine' | 'collection'>('machine');
  const [showConfetti, setShowConfetti] = useState(false);
  const [floatingCoins, setFloatingCoins] = useState<number[]>([]);
  const [lastToy, setLastToy] = useState<Toy | null>(null);
  const [coinIdCounter, setCoinIdCounter] = useState(0);

  // Persist state
  useEffect(() => {
    localStorage.setItem('gashapon_collected', JSON.stringify(collected));
  }, [collected]);

  useEffect(() => {
    localStorage.setItem('gashapon_coins', String(coins));
  }, [coins]);

  const handleNewToy = (toy: Toy) => {
    setCollected((prev) => [...prev, toy]);
    setLastToy(toy);
    // Show confetti for rare+
    if (toy.rarity === 'rare' || toy.rarity === 'epic' || toy.rarity === 'legendary') {
      setShowConfetti(true);
      setTimeout(() => setShowConfetti(false), 2000);
    }
    // Switch to collection tab after a delay
    setTimeout(() => {
      setActiveTab('collection');
    }, 2500);
  };

  const handleSpendCoin = () => {
    setCoins((c) => Math.max(0, c - 1));
  };

  const handleAddCoins = (amount: number) => {
    setCoins((c) => c + amount);
    // Floating coin animation
    const ids = Array.from({ length: Math.min(amount, 5) }, (_, i) => {
      const id = coinIdCounter + i;
      return id;
    });
    setCoinIdCounter((prev) => prev + ids.length);
    setFloatingCoins((prev) => [...prev, ...ids]);
  };

  const handleRemoveFloatingCoin = (id: number) => {
    setFloatingCoins((prev) => prev.filter((c) => c !== id));
  };

  const handleReset = () => {
    if (window.confirm('Reset your entire collection? This cannot be undone.')) {
      const starterToys = STARTER_COLLECTION.map((id) => ALL_TOYS.find((t) => t.id === id)!).filter(Boolean);
      setCollected(starterToys);
      setCoins(INITIAL_COINS);
      setLastToy(null);
    }
  };

  const uniqueCount = new Set(collected.map((t) => t.id)).size;
  const legendaryCount = collected.filter((t) => t.rarity === 'legendary').length;

  return (
    <div
      className="min-h-screen relative overflow-hidden"
      style={{
        background: 'linear-gradient(135deg, #0f0520 0%, #1a0535 25%, #0d1a40 60%, #0a0f2e 100%)',
      }}
    >
      {/* Background decoration */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden">
        {/* Stars */}
        {Array.from({ length: 60 }).map((_, i) => (
          <div
            key={i}
            className="absolute rounded-full"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              width: Math.random() > 0.8 ? 3 : 1.5,
              height: Math.random() > 0.8 ? 3 : 1.5,
              background: 'white',
              opacity: 0.2 + Math.random() * 0.5,
              animation: `capsule-bounce ${2 + Math.random() * 3}s ease-in-out ${Math.random() * 3}s infinite`,
            }}
          />
        ))}
        {/* Gradient orbs */}
        <div
          className="absolute rounded-full blur-3xl opacity-20"
          style={{ width: 400, height: 400, top: '-100px', left: '-100px', background: '#ec4899' }}
        />
        <div
          className="absolute rounded-full blur-3xl opacity-15"
          style={{ width: 300, height: 300, bottom: '-50px', right: '-50px', background: '#6366f1' }}
        />
        <div
          className="absolute rounded-full blur-3xl opacity-10"
          style={{ width: 200, height: 200, top: '40%', left: '30%', background: '#fbbf24' }}
        />
      </div>

      {/* Confetti */}
      <Confetti active={showConfetti} count={50} />

      {/* Floating coins */}
      {floatingCoins.map((id) => (
        <FloatingCoin key={id} id={id} onDone={handleRemoveFloatingCoin} />
      ))}

      {/* ── App Shell ── */}
      <div className="relative z-10 max-w-5xl mx-auto px-4 py-6">

        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-white font-black text-3xl tracking-tight leading-none">
              🎰 Gashapon
            </h1>
            <p className="text-white/40 text-sm mt-0.5">Collect 'em all!</p>
          </div>

          {/* Stats pills */}
          <div className="flex items-center gap-2">
            <div
              className="flex items-center gap-1.5 rounded-full px-3 py-1.5 text-sm font-bold"
              style={{ background: 'rgba(255,255,255,0.08)', color: 'rgba(255,255,255,0.7)' }}
            >
              📦 {uniqueCount}/{ALL_TOYS.length}
            </div>
            {legendaryCount > 0 && (
              <div
                className="flex items-center gap-1.5 rounded-full px-3 py-1.5 text-sm font-bold"
                style={{
                  background: 'rgba(251,191,36,0.15)',
                  color: '#fbbf24',
                  border: '1px solid rgba(251,191,36,0.3)',
                }}
              >
                ✨ {legendaryCount} Legendary!
              </div>
            )}
            <button
              onClick={handleReset}
              className="text-white/20 hover:text-white/50 text-xs transition-colors px-2 py-1 rounded-lg hover:bg-white/5"
              title="Reset collection"
            >
              ↺ Reset
            </button>
          </div>
        </div>

        {/* Tab navigation */}
        <div
          className="flex rounded-2xl p-1 mb-6"
          style={{ background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.1)' }}
        >
          {[
            { id: 'machine', label: '🎰 Machine', desc: 'Roll for toys' },
            { id: 'collection', label: '📦 Collection', desc: `${uniqueCount} collected` },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as 'machine' | 'collection')}
              className="flex-1 rounded-xl py-2 px-4 transition-all duration-200 text-sm font-bold flex items-center justify-center gap-2"
              style={{
                background: activeTab === tab.id
                  ? 'rgba(255,255,255,0.12)'
                  : 'transparent',
                color: activeTab === tab.id ? 'white' : 'rgba(255,255,255,0.4)',
                boxShadow: activeTab === tab.id ? '0 2px 8px rgba(0,0,0,0.2)' : 'none',
              }}
            >
              {tab.label}
              <span
                className="hidden sm:inline text-xs font-normal"
                style={{ color: activeTab === tab.id ? 'rgba(255,255,255,0.5)' : 'rgba(255,255,255,0.2)' }}
              >
                {tab.desc}
              </span>
            </button>
          ))}
        </div>

        {/* ── Machine View ── */}
        {activeTab === 'machine' && (
          <div className="flex flex-col lg:flex-row gap-6 items-start justify-center">
            {/* Machine column */}
            <div className="flex flex-col items-center gap-4 w-full lg:w-auto">
              <GashaponMachine
                onNewToy={handleNewToy}
                coins={coins}
                onSpendCoin={handleSpendCoin}
              />

              {/* Coin shop below machine */}
              <div className="w-full" style={{ maxWidth: 320 }}>
                <CoinShop coins={coins} onAddCoins={handleAddCoins} />
              </div>
            </div>

            {/* Info / last pull sidebar */}
            <div className="flex-1 flex flex-col gap-4 w-full lg:max-w-xs">
              {/* How to play */}
              <div
                className="rounded-2xl p-4"
                style={{ background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.1)' }}
              >
                <h3 className="text-white font-black text-sm mb-3 flex items-center gap-2">
                  📖 How to Play
                </h3>
                <ol className="space-y-2">
                  {[
                    { icon: '🪙', text: 'Get coins from the Coin Shop' },
                    { icon: '🎰', text: 'Click the pink crank to spin!' },
                    { icon: '💊', text: 'Watch your capsule drop' },
                    { icon: '✨', text: 'Discover rare toys & fill your shelf' },
                  ].map((step, i) => (
                    <li key={i} className="flex items-start gap-2 text-xs text-white/60">
                      <span className="text-base leading-none">{step.icon}</span>
                      <span className="leading-tight">{step.text}</span>
                    </li>
                  ))}
                </ol>
              </div>

              {/* Rarity odds */}
              <div
                className="rounded-2xl p-4"
                style={{ background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.1)' }}
              >
                <h3 className="text-white font-black text-sm mb-3">🎲 Rarity Odds</h3>
                <div className="space-y-2">
                  {(['legendary', 'epic', 'rare', 'uncommon', 'common'] as const).map((r) => {
                    const config = RARITY_CONFIG[r];
                    const totalWeight = Object.values(RARITY_CONFIG).reduce((s, c) => s + c.weight, 0);
                    const pct = ((config.weight / totalWeight) * 100).toFixed(1);
                    return (
                      <div key={r} className="flex items-center gap-2">
                        <div
                          className="rounded-full"
                          style={{ width: 8, height: 8, minWidth: 8, background: config.color, boxShadow: `0 0 5px ${config.color}` }}
                        />
                        <div className="flex-1">
                          <div
                            className="h-1.5 rounded-full"
                            style={{
                              background: `linear-gradient(90deg, ${config.color}, ${config.color}88)`,
                              width: `${(config.weight / totalWeight) * 100}%`,
                              minWidth: 4,
                            }}
                          />
                        </div>
                        <span className="text-xs font-semibold" style={{ color: config.color, minWidth: 36, textAlign: 'right' }}>
                          {pct}%
                        </span>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Last pull summary */}
              {lastToy && (
                <div
                  className="rounded-2xl p-4 animate-slide-up-in"
                  style={{
                    background: 'rgba(255,255,255,0.05)',
                    border: `1px solid ${RARITY_CONFIG[lastToy.rarity].color}44`,
                  }}
                >
                  <h3 className="text-white/50 text-xs font-semibold uppercase tracking-widest mb-2">
                    Last Pull
                  </h3>
                  <div className="flex items-center gap-3">
                    <span className="text-3xl">{lastToy.emoji}</span>
                    <div>
                      <p className="text-white font-bold text-sm">{lastToy.name}</p>
                      <p
                        className="text-xs font-semibold"
                        style={{ color: RARITY_CONFIG[lastToy.rarity].color }}
                      >
                        {'★'.repeat(RARITY_CONFIG[lastToy.rarity].stars)} {RARITY_CONFIG[lastToy.rarity].label}
                      </p>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}

        {/* ── Collection View ── */}
        {activeTab === 'collection' && (
          <div className="animate-slide-up-in">
            <CollectibleShelf collected={collected} />
          </div>
        )}
      </div>
    </div>
  );
}
