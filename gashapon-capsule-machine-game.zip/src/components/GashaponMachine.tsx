import React, { useState, useRef, useEffect } from 'react';
import { Toy, RARITY_CONFIG, rollToy } from '../data/toys';
import SparkleEffect from './SparkleEffect';

interface GashaponMachineProps {
  onNewToy: (toy: Toy) => void;
  coins: number;
  onSpendCoin: () => void;
}

type MachineState = 'idle' | 'cranking' | 'dropping' | 'reveal';

// ── Capsule SVG ──────────────────────────────────────────────────────────────
const CapsuleSVG: React.FC<{
  color: string;
  capColor: string;
  size?: number;
  className?: string;
}> = ({ color, capColor, size = 64, className = '' }) => (
  <svg width={size} height={size} viewBox="0 0 64 64" className={className}>
    <defs>
      <radialGradient id="capGrad" cx="35%" cy="30%" r="65%">
        <stop offset="0%" stopColor="white" stopOpacity="0.5" />
        <stop offset="100%" stopColor={capColor} stopOpacity="1" />
      </radialGradient>
      <radialGradient id="bodyGrad" cx="35%" cy="30%" r="65%">
        <stop offset="0%" stopColor="white" stopOpacity="0.4" />
        <stop offset="100%" stopColor={color} stopOpacity="1" />
      </radialGradient>
    </defs>
    {/* Bottom half */}
    <path
      d="M 32 60 A 20 20 0 0 1 12 40 L 12 32 L 52 32 L 52 40 A 20 20 0 0 1 32 60 Z"
      fill="url(#bodyGrad)"
      stroke={color}
      strokeWidth="1.5"
    />
    {/* Top half (cap) */}
    <path
      d="M 32 4 A 20 20 0 0 1 52 24 L 52 32 L 12 32 L 12 24 A 20 20 0 0 1 32 4 Z"
      fill="url(#capGrad)"
      stroke={capColor}
      strokeWidth="1.5"
    />
    {/* Seam line */}
    <line x1="12" y1="32" x2="52" y2="32" stroke="rgba(0,0,0,0.15)" strokeWidth="1.5" />
    {/* Highlight */}
    <ellipse cx="25" cy="18" rx="6" ry="4" fill="rgba(255,255,255,0.35)" transform="rotate(-20 25 18)" />
  </svg>
);

// ── Crank SVG ────────────────────────────────────────────────────────────────
const CrankSVG: React.FC<{ rotation: number; onClick: () => void; disabled: boolean }> = ({
  rotation,
  onClick,
  disabled,
}) => (
  <div
    onClick={disabled ? undefined : onClick}
    className={`relative cursor-pointer transition-transform duration-100 ${disabled ? 'opacity-40 cursor-not-allowed' : 'hover:scale-110 active:scale-95'}`}
    title={disabled ? 'Need a coin!' : 'Turn the crank!'}
    style={{ width: 80, height: 80 }}
  >
    <svg
      width="80"
      height="80"
      viewBox="0 0 80 80"
      style={{ transform: `rotate(${rotation}deg)`, transition: 'transform 0.05s linear' }}
    >
      <defs>
        <radialGradient id="crankGrad" cx="40%" cy="30%" r="60%">
          <stop offset="0%" stopColor="#f9a8d4" />
          <stop offset="100%" stopColor="#ec4899" />
        </radialGradient>
      </defs>
      {/* Arm */}
      <rect x="37" y="10" width="6" height="40" rx="3" fill="#ec4899" />
      {/* Center hub */}
      <circle cx="40" cy="40" r="10" fill="url(#crankGrad)" stroke="#be185d" strokeWidth="2" />
      <circle cx="40" cy="40" r="4" fill="#be185d" />
      {/* Handle */}
      <circle cx="40" cy="12" r="8" fill="#fda4af" stroke="#ec4899" strokeWidth="2" />
      <circle cx="40" cy="12" r="4" fill="#fb7185" />
      {/* Shine */}
      <circle cx="38" cy="10" r="2" fill="rgba(255,255,255,0.6)" />
    </svg>
    {!disabled && (
      <div className="absolute inset-0 flex items-center justify-center opacity-0 hover:opacity-100 transition-opacity">
        <div className="absolute inset-0 rounded-full bg-pink-300 opacity-20 animate-ping" />
      </div>
    )}
  </div>
);

// Fixed rotations so they don't change on re-render
const CAPSULE_ROTATIONS = [-25, 15, -10, 30, -18, 22, -35, 8];

// ── Machine Capsule Display (inside globe) ───────────────────────────────────
const CapsuleDisplay: React.FC<{ toys: { color: string; capColor: string }[] }> = ({ toys }) => {
  const positions = [
    { x: 28, y: 30 }, { x: 55, y: 25 }, { x: 70, y: 45 },
    { x: 40, y: 55 }, { x: 20, y: 55 }, { x: 60, y: 65 },
    { x: 45, y: 38 }, { x: 15, y: 38 },
  ];

  return (
    <>
      {toys.slice(0, positions.length).map((toy, i) => (
        <div
          key={i}
          className="absolute"
          style={{
            left: `${positions[i].x}%`,
            top: `${positions[i].y}%`,
            transform: `translate(-50%, -50%) rotate(${CAPSULE_ROTATIONS[i] ?? 0}deg)`,
          }}
        >
          <CapsuleSVG color={toy.color} capColor={toy.capColor} size={28} />
        </div>
      ))}
    </>
  );
};

// ── Main Component ───────────────────────────────────────────────────────────
const GashaponMachine: React.FC<GashaponMachineProps> = ({ onNewToy, coins, onSpendCoin }) => {
  const [machineState, setMachineState] = useState<MachineState>('idle');
  const [crankRotation, setCrankRotation] = useState(0);
  const [droppedToy, setDroppedToy] = useState<Toy | null>(null);
  const [showSparkle, setShowSparkle] = useState(false);
  const [showReveal, setShowReveal] = useState(false);
  const [shakeMachine, setShakeMachine] = useState(false);
  const [capsuleVisible, setCapsuleVisible] = useState(false);
  const crankRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const stateRef = useRef(machineState);

  stateRef.current = machineState;

  // Pre-fill machine with random capsule colors
  const machineCapsules = [
    { color: '#f97316', capColor: '#fb923c' },
    { color: '#22c55e', capColor: '#4ade80' },
    { color: '#ec4899', capColor: '#f472b6' },
    { color: '#6366f1', capColor: '#818cf8' },
    { color: '#eab308', capColor: '#facc15' },
    { color: '#0ea5e9', capColor: '#38bdf8' },
    { color: '#dc2626', capColor: '#ef4444' },
    { color: '#7c3aed', capColor: '#8b5cf6' },
  ];

  const handleCrank = () => {
    if (machineState !== 'idle' || coins <= 0) return;

    onSpendCoin();
    setMachineState('cranking');
    setShowReveal(false);
    setCapsuleVisible(false);
    setDroppedToy(null);

    let turns = 0;
    const targetTurns = 360 * 2; // 2 full rotations
    const step = 18;
    const interval = 25;

    if (crankRef.current) clearInterval(crankRef.current);
    crankRef.current = setInterval(() => {
      turns += step;
      setCrankRotation((prev) => prev + step);

      if (turns >= targetTurns) {
        clearInterval(crankRef.current!);
        // Shake machine
        setShakeMachine(true);
        setTimeout(() => setShakeMachine(false), 500);

        // Drop capsule
        setTimeout(() => {
          const toy = rollToy();
          setDroppedToy(toy);
          setMachineState('dropping');
          setCapsuleVisible(true);

          setTimeout(() => {
            setShowSparkle(true);
            setMachineState('reveal');
            setShowReveal(true);
            setTimeout(() => {
              setShowSparkle(false);
              onNewToy(toy);
            }, 1200);
          }, 700);
        }, 300);
      }
    }, interval);
  };

  useEffect(() => {
    return () => {
      if (crankRef.current) clearInterval(crankRef.current);
    };
  }, []);

  const rarityConfig = droppedToy ? RARITY_CONFIG[droppedToy.rarity] : null;



  return (
    <div className="flex flex-col items-center gap-6 no-select">
      {/* ── Machine Body ── */}
      <div
        className={`relative ${shakeMachine ? 'animate-machine-shake' : ''}`}
        style={{ width: 320 }}
      >
        {/* Machine outer frame */}
        <div
          className="relative rounded-3xl overflow-hidden"
          style={{
            background: 'linear-gradient(145deg, #ff6eb4, #e91e8c, #c2185b)',
            boxShadow: '0 20px 60px rgba(233,30,140,0.4), inset 0 2px 4px rgba(255,255,255,0.3)',
            padding: '12px 12px 16px',
          }}
        >
          {/* Top label */}
          <div
            className="text-center py-2 mb-3 rounded-xl text-white font-black text-lg tracking-widest"
            style={{
              background: 'linear-gradient(90deg, #c2185b, #880e4f, #c2185b)',
              textShadow: '0 1px 4px rgba(0,0,0,0.4)',
              border: '2px solid rgba(255,255,255,0.3)',
              letterSpacing: '0.25em',
            }}
          >
            ✦ GASHAPON ✦
          </div>

          {/* Globe / capsule container */}
          <div
            className="relative mx-auto rounded-full overflow-hidden mb-3"
            style={{
              width: 220,
              height: 220,
              background: 'radial-gradient(ellipse at 35% 30%, rgba(255,255,255,0.9) 0%, rgba(200,230,255,0.7) 40%, rgba(150,200,255,0.4) 100%)',
              boxShadow: 'inset 0 8px 24px rgba(255,255,255,0.8), inset -4px -8px 24px rgba(100,160,230,0.3), 0 4px 16px rgba(0,0,0,0.2)',
              border: '6px solid rgba(255,255,255,0.6)',
            }}
          >
            {/* Capsules inside */}
            <CapsuleDisplay toys={machineCapsules} />

            {/* Globe shine */}
            <div
              className="absolute"
              style={{
                top: '8%',
                left: '15%',
                width: '35%',
                height: '25%',
                background: 'radial-gradient(ellipse, rgba(255,255,255,0.7) 0%, transparent 100%)',
                borderRadius: '50%',
                filter: 'blur(4px)',
                pointerEvents: 'none',
              }}
            />
          </div>

          {/* Neck / funnel */}
          <div
            className="mx-auto"
            style={{
              width: 0,
              height: 0,
              borderLeft: '40px solid transparent',
              borderRight: '40px solid transparent',
              borderTop: '20px solid rgba(200,100,150,0.5)',
            }}
          />
          <div
            className="mx-auto rounded-b-lg"
            style={{
              width: 60,
              height: 12,
              background: 'linear-gradient(180deg, #c2185b, #880e4f)',
              boxShadow: 'inset 0 2px 4px rgba(0,0,0,0.3)',
            }}
          />

          {/* Machine bottom body */}
          <div
            className="rounded-2xl p-3 mt-2"
            style={{
              background: 'linear-gradient(145deg, #ad1457, #880e4f)',
              boxShadow: 'inset 0 2px 8px rgba(0,0,0,0.3)',
            }}
          >
            {/* Coin slot row */}
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <div
                  className="rounded-full flex items-center justify-center text-yellow-900 font-bold text-sm"
                  style={{
                    width: 36,
                    height: 36,
                    background: 'linear-gradient(145deg, #fde68a, #f59e0b, #d97706)',
                    boxShadow: '0 2px 8px rgba(245,158,11,0.5)',
                  }}
                >
                  {coins}
                </div>
                <span className="text-pink-200 text-xs font-semibold">COINS</span>
              </div>

              {/* Crank */}
              <CrankSVG
                rotation={crankRotation}
                onClick={handleCrank}
                disabled={machineState !== 'idle' || coins <= 0}
              />
            </div>

            {/* Tray / output slot */}
            <div
              className="relative rounded-xl overflow-hidden flex items-center justify-center"
              style={{
                height: 80,
                background: 'linear-gradient(180deg, #3d0020, #1a0010)',
                boxShadow: 'inset 0 4px 12px rgba(0,0,0,0.6)',
                border: '3px solid rgba(255,255,255,0.1)',
              }}
            >
              {/* Tray opening flap */}
              <div
                className="absolute bottom-0 left-0 right-0 rounded-b-xl"
                style={{
                  height: 16,
                  background: 'linear-gradient(180deg, #880e4f, #ad1457)',
                }}
              />

              {/* Dropped capsule */}
              <div className="relative flex items-center justify-center" style={{ height: 60 }}>
                {capsuleVisible && droppedToy && (
                  <div
                    className={`relative ${machineState === 'dropping' || machineState === 'reveal' ? 'animate-capsule-drop' : ''}`}
                  >
                    <SparkleEffect
                      rarity={droppedToy.rarity}
                      active={showSparkle}
                    />
                    <div
                      style={{
                        filter: showReveal
                          ? `drop-shadow(0 0 12px ${rarityConfig?.color})`
                          : 'none',
                        transition: 'filter 0.3s ease',
                      }}
                    >
                      <CapsuleSVG
                        color={droppedToy.capsuleColor}
                        capColor={droppedToy.capColor}
                        size={56}
                        className={machineState === 'reveal' ? 'animate-capsule-bounce' : ''}
                      />
                    </div>

                    {/* Rarity badge */}
                    {showReveal && (
                      <div
                        className="absolute -top-8 left-1/2 -translate-x-1/2 whitespace-nowrap animate-slide-up-in"
                        style={{
                          padding: '2px 8px',
                          borderRadius: 999,
                          background: rarityConfig?.color,
                          color: droppedToy.rarity === 'common' ? '#374151' : 'white',
                          fontSize: 10,
                          fontWeight: 800,
                          letterSpacing: '0.1em',
                          boxShadow: `0 0 12px ${rarityConfig?.color}`,
                        }}
                      >
                        {droppedToy.rarity === 'legendary' && '★ '}
                        {rarityConfig?.label.toUpperCase()}
                        {droppedToy.rarity === 'legendary' && ' ★'}
                      </div>
                    )}
                  </div>
                )}

                {!capsuleVisible && machineState === 'idle' && (
                  <p className="text-pink-300 text-xs text-center opacity-60">
                    {coins > 0 ? 'Turn the crank!' : 'No coins left'}
                  </p>
                )}

                {machineState === 'cranking' && (
                  <div className="flex gap-1">
                    {[0, 1, 2].map((i) => (
                      <div
                        key={i}
                        className="w-2 h-2 rounded-full bg-pink-400"
                        style={{ animation: `capsule-bounce 0.6s ease-in-out ${i * 0.2}s infinite` }}
                      />
                    ))}
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* ── Reveal Card ── */}
      {showReveal && droppedToy && (
        <div
          className="animate-slide-up-in rounded-2xl p-4 text-center w-full max-w-xs relative overflow-hidden"
          style={{
            background:
              droppedToy.rarity === 'legendary'
                ? 'linear-gradient(135deg, #1a0e00, #2d1a00)'
                : droppedToy.rarity === 'epic'
                ? 'linear-gradient(135deg, #1a0035, #2d0050)'
                : 'rgba(255,255,255,0.12)',
            border: `2px solid ${rarityConfig?.color}`,
            boxShadow:
              droppedToy.rarity === 'legendary'
                ? `0 0 30px ${rarityConfig?.color}88, 0 0 60px ${rarityConfig?.color}44`
                : droppedToy.rarity === 'epic'
                ? `0 0 20px ${rarityConfig?.color}66`
                : `0 4px 20px ${rarityConfig?.color}44`,
            animation:
              droppedToy.rarity === 'legendary'
                ? 'legendary-aura 2s ease-in-out infinite'
                : undefined,
          }}
        >
          {/* Shine sweep */}
          <div
            className="absolute top-0 bottom-0 w-16 pointer-events-none"
            style={{
              background: 'linear-gradient(90deg, transparent, rgba(255,255,255,0.15), transparent)',
              animation: 'reveal-shine 1.5s ease-in-out 0.3s',
            }}
          />

          <div className="text-5xl mb-2">{droppedToy.emoji}</div>
          <div
            className={`font-black text-xl mb-1 ${droppedToy.rarity === 'legendary' ? 'legendary-text' : 'text-white'}`}
          >
            {droppedToy.name}
          </div>
          <div
            className="text-xs font-bold mb-2 tracking-widest"
            style={{ color: rarityConfig?.color }}
          >
            {'★'.repeat(rarityConfig?.stars ?? 1)}
            {'☆'.repeat(5 - (rarityConfig?.stars ?? 1))}
          </div>
          <p className="text-white/60 text-xs">{droppedToy.description}</p>
        </div>
      )}
    </div>
  );
};

export default GashaponMachine;
