import React, { useState } from 'react';
import { Toy, RARITY_CONFIG, ALL_TOYS } from '../data/toys';

interface CollectibleShelfProps {
  collected: Toy[];
}

type FilterRarity = 'all' | 'common' | 'uncommon' | 'rare' | 'epic' | 'legendary';

const ToyCard: React.FC<{ toy: Toy; count: number; isNew?: boolean }> = ({ toy, count, isNew }) => {
  const [hovered, setHovered] = useState(false);
  const config = RARITY_CONFIG[toy.rarity];

  const borderAnimClass =
    toy.rarity === 'legendary'
      ? 'border-yellow-400'
      : toy.rarity === 'epic'
      ? 'border-purple-400'
      : '';

  return (
    <div
      className="relative flex flex-col items-center cursor-pointer transition-all duration-200"
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      style={{ transform: hovered ? 'translateY(-6px) scale(1.05)' : 'none' }}
    >
      {/* Card */}
      <div
        className={`relative rounded-2xl p-3 flex flex-col items-center gap-1 border-2 ${borderAnimClass}`}
        style={{
          width: 80,
          background:
            toy.rarity === 'legendary'
              ? 'linear-gradient(135deg, #1a0e00 0%, #2d1a00 50%, #1a0e00 100%)'
              : toy.rarity === 'epic'
              ? 'linear-gradient(135deg, #1a0035, #2d0050)'
              : 'rgba(255,255,255,0.08)',
          borderColor: config.color,
          boxShadow: hovered
            ? `0 8px 24px ${config.color}66, 0 0 0 1px ${config.color}44`
            : `0 2px 8px ${config.color}33`,
          animation:
            toy.rarity === 'legendary' && hovered
              ? 'legendary-aura 1.5s ease-in-out infinite'
              : undefined,
        }}
      >
        {/* New badge */}
        {isNew && (
          <div
            className="absolute -top-2 -right-2 text-white text-xs font-black rounded-full px-1.5 py-0.5 animate-wiggle"
            style={{ background: '#ef4444', fontSize: 9, lineHeight: 1.5 }}
          >
            NEW
          </div>
        )}

        {/* Count badge */}
        {count > 1 && (
          <div
            className="absolute -top-2 -left-2 text-white text-xs font-black rounded-full flex items-center justify-center"
            style={{
              width: 20,
              height: 20,
              background: config.color,
              fontSize: 10,
              boxShadow: `0 2px 6px ${config.color}88`,
            }}
          >
            {count}
          </div>
        )}

        {/* Emoji */}
        <div
          className="text-3xl"
          style={{
            filter:
              toy.rarity === 'legendary'
                ? `drop-shadow(0 0 6px ${config.color})`
                : toy.rarity === 'epic'
                ? `drop-shadow(0 0 4px ${config.color})`
                : 'none',
            animation:
              toy.rarity === 'legendary'
                ? 'star-spin 4s linear infinite'
                : undefined,
          }}
        >
          {toy.emoji}
        </div>

        {/* Stars */}
        <div className="flex gap-0.5">
          {Array.from({ length: 5 }).map((_, i) => (
            <span
              key={i}
              style={{
                fontSize: 7,
                color: i < (RARITY_CONFIG[toy.rarity].stars) ? config.color : 'rgba(255,255,255,0.2)',
              }}
            >
              ★
            </span>
          ))}
        </div>

        {/* Name */}
        <p
          className="text-center font-bold leading-tight"
          style={{
            fontSize: 9,
            color:
              toy.rarity === 'legendary'
                ? '#fbbf24'
                : toy.rarity === 'epic'
                ? '#d8b4fe'
                : 'rgba(255,255,255,0.85)',
            maxWidth: 60,
          }}
        >
          {toy.name}
        </p>
      </div>

      {/* Tooltip */}
      {hovered && (
        <div
          className="absolute bottom-full mb-2 left-1/2 -translate-x-1/2 z-50 rounded-xl p-3 text-center pointer-events-none animate-slide-up-in"
          style={{
            width: 140,
            background: 'rgba(10,10,20,0.95)',
            border: `1px solid ${config.color}`,
            boxShadow: `0 8px 24px rgba(0,0,0,0.5), 0 0 12px ${config.color}44`,
          }}
        >
          <div className="text-2xl mb-1">{toy.emoji}</div>
          <p className="font-black text-white text-xs mb-0.5">{toy.name}</p>
          <p className="text-xs font-semibold mb-1" style={{ color: config.color }}>
            {config.label}
          </p>
          <p className="text-white/50 text-xs leading-tight">{toy.description}</p>
          {count > 1 && (
            <p className="text-white/40 text-xs mt-1">Owned: {count}x</p>
          )}
        </div>
      )}
    </div>
  );
};

// Locked toy slot
const LockedToyCard: React.FC<{ toy: Toy }> = ({ toy }) => {
  const config = RARITY_CONFIG[toy.rarity];
  return (
    <div
      className="relative flex flex-col items-center opacity-25"
      title={`${toy.name} — Not yet collected`}
    >
      <div
        className="rounded-2xl p-3 flex flex-col items-center gap-1 border-2 border-dashed"
        style={{
          width: 80,
          background: 'rgba(255,255,255,0.03)',
          borderColor: config.color + '44',
        }}
      >
        <div className="text-3xl grayscale">❓</div>
        <div className="flex gap-0.5">
          {Array.from({ length: 5 }).map((_, i) => (
            <span key={i} style={{ fontSize: 7, color: 'rgba(255,255,255,0.15)' }}>★</span>
          ))}
        </div>
        <p className="text-center font-bold text-white/30 leading-tight" style={{ fontSize: 9, maxWidth: 60 }}>
          ???
        </p>
      </div>
    </div>
  );
};

const CollectibleShelf: React.FC<CollectibleShelfProps> = ({ collected }) => {
  const [filter, setFilter] = useState<FilterRarity>('all');
  const [newIds, setNewIds] = useState<Set<string>>(new Set());
  const prevCountRef = React.useRef(collected.length);

  // Detect newly added toys
  React.useEffect(() => {
    if (collected.length > prevCountRef.current) {
      const latest = collected[collected.length - 1];
      setNewIds((prev) => new Set([...prev, latest.id + '_' + Date.now()]));
      setTimeout(() => {
        setNewIds(new Set());
      }, 4000);
    }
    prevCountRef.current = collected.length;
  }, [collected.length]);

  // Count occurrences
  const counts = collected.reduce<Record<string, number>>((acc, toy) => {
    acc[toy.id] = (acc[toy.id] ?? 0) + 1;
    return acc;
  }, {});

  // Unique collected toys
  const uniqueCollected = Array.from(
    new Map(collected.map((t) => [t.id, t])).values()
  );

  const rarityOrder = ['legendary', 'epic', 'rare', 'uncommon', 'common'];
  const sortedCollected = [...uniqueCollected].sort(
    (a, b) => rarityOrder.indexOf(a.rarity) - rarityOrder.indexOf(b.rarity)
  );

  const filteredCollected =
    filter === 'all'
      ? sortedCollected
      : sortedCollected.filter((t) => t.rarity === filter);

  // Not yet collected
  const collectedIds = new Set(uniqueCollected.map((t) => t.id));
  const lockedToys = ALL_TOYS.filter(
    (t) => !collectedIds.has(t.id) && (filter === 'all' || t.rarity === filter)
  );

  const filterButtons: { label: string; value: FilterRarity; color?: string }[] = [
    { label: 'All', value: 'all' },
    { label: '★ Common', value: 'common', color: RARITY_CONFIG.common.color },
    { label: '★★ Uncommon', value: 'uncommon', color: RARITY_CONFIG.uncommon.color },
    { label: '★★★ Rare', value: 'rare', color: RARITY_CONFIG.rare.color },
    { label: '★★★★ Epic', value: 'epic', color: RARITY_CONFIG.epic.color },
    { label: '★★★★★ Legendary', value: 'legendary', color: RARITY_CONFIG.legendary.color },
  ];

  return (
    <div className="flex flex-col gap-4 w-full">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-white font-black text-xl tracking-wide">📦 Collection</h2>
          <p className="text-white/50 text-xs mt-0.5">
            {uniqueCollected.length} / {ALL_TOYS.length} discovered · {collected.length} total
          </p>
        </div>
        <div
          className="rounded-full px-3 py-1 text-sm font-bold"
          style={{
            background: 'rgba(255,255,255,0.1)',
            color: 'rgba(255,255,255,0.7)',
          }}
        >
          {Math.round((uniqueCollected.length / ALL_TOYS.length) * 100)}% complete
        </div>
      </div>

      {/* Rarity filter pills */}
      <div className="flex flex-wrap gap-2">
        {filterButtons.map((btn) => (
          <button
            key={btn.value}
            onClick={() => setFilter(btn.value)}
            className="rounded-full px-3 py-1 text-xs font-bold transition-all duration-150"
            style={{
              background: filter === btn.value
                ? (btn.color ?? 'white')
                : 'rgba(255,255,255,0.08)',
              color: filter === btn.value
                ? (btn.value === 'common' || btn.value === 'all' ? '#111' : 'white')
                : (btn.color ?? 'rgba(255,255,255,0.5)'),
              border: `1px solid ${filter === btn.value ? (btn.color ?? 'white') : 'transparent'}`,
              boxShadow: filter === btn.value ? `0 0 12px ${btn.color ?? '#ffffff'}66` : 'none',
            }}
          >
            {btn.label}
          </button>
        ))}
      </div>

      {/* Shelf Wood */}
      <div
        className="rounded-2xl p-4 relative overflow-hidden"
        style={{
          background: 'linear-gradient(180deg, rgba(255,255,255,0.06) 0%, rgba(255,255,255,0.02) 100%)',
          border: '1px solid rgba(255,255,255,0.1)',
          backdropFilter: 'blur(8px)',
        }}
      >
        {/* Shelf lines */}
        {uniqueCollected.length === 0 && filter === 'all' ? (
          <div className="text-center py-8">
            <p className="text-4xl mb-3">📭</p>
            <p className="text-white/40 font-semibold">No toys collected yet!</p>
            <p className="text-white/25 text-sm mt-1">Turn the crank to get started</p>
          </div>
        ) : (
          <div className="flex flex-wrap gap-4 justify-start">
            {filteredCollected.map((toy, i) => (
              <ToyCard
                key={toy.id}
                toy={toy}
                count={counts[toy.id] ?? 1}
                isNew={newIds.size > 0 && i === 0}
              />
            ))}
            {lockedToys.map((toy) => (
              <LockedToyCard key={toy.id} toy={toy} />
            ))}
          </div>
        )}
      </div>

      {/* Rarity breakdown */}
      {uniqueCollected.length > 0 && (
        <div
          className="rounded-2xl p-3"
          style={{ background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)' }}
        >
          <p className="text-white/40 text-xs font-semibold mb-2 uppercase tracking-widest">Rarity Breakdown</p>
          <div className="flex flex-wrap gap-2">
            {(['legendary', 'epic', 'rare', 'uncommon', 'common'] as const).map((r) => {
              const cnt = uniqueCollected.filter((t) => t.rarity === r).length;
              const total = ALL_TOYS.filter((t) => t.rarity === r).length;
              const config = RARITY_CONFIG[r];
              return (
                <div key={r} className="flex items-center gap-1.5">
                  <div
                    className="rounded-full"
                    style={{ width: 8, height: 8, background: config.color, boxShadow: `0 0 6px ${config.color}` }}
                  />
                  <span className="text-xs" style={{ color: config.color }}>
                    {config.label}: {cnt}/{total}
                  </span>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};

export default CollectibleShelf;
