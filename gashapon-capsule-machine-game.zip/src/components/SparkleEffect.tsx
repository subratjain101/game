import React, { useEffect, useState } from 'react';
import { Rarity, RARITY_CONFIG } from '../data/toys';

interface Particle {
  id: number;
  x: number;
  y: number;
  size: number;
  tx: number;
  ty: number;
  delay: number;
  duration: number;
  shape: 'star' | 'circle' | 'diamond';
  color: string;
}

interface SparkleEffectProps {
  rarity: Rarity;
  active: boolean;
  count?: number;
}

const SHAPES = ['star', 'circle', 'diamond'] as const;

const ShapeSVG: React.FC<{ shape: string; color: string; size: number }> = ({ shape, color, size }) => {
  if (shape === 'star') {
    return (
      <svg width={size} height={size} viewBox="0 0 24 24" fill={color}>
        <polygon points="12,2 15.09,8.26 22,9.27 17,14.14 18.18,21.02 12,17.77 5.82,21.02 7,14.14 2,9.27 8.91,8.26" />
      </svg>
    );
  }
  if (shape === 'diamond') {
    return (
      <svg width={size} height={size} viewBox="0 0 24 24" fill={color}>
        <polygon points="12,2 22,12 12,22 2,12" />
      </svg>
    );
  }
  return (
    <div
      style={{
        width: size,
        height: size,
        borderRadius: '50%',
        background: color,
        boxShadow: `0 0 ${size}px ${color}`,
      }}
    />
  );
};

const SparkleEffect: React.FC<SparkleEffectProps> = ({ rarity, active, count }) => {
  const [particles, setParticles] = useState<Particle[]>([]);
  const config = RARITY_CONFIG[rarity];

  const particleCount = count ?? (
    rarity === 'legendary' ? 30 :
    rarity === 'epic' ? 22 :
    rarity === 'rare' ? 16 :
    rarity === 'uncommon' ? 10 : 6
  );

  const extraColors: Record<Rarity, string[]> = {
    legendary: ['#fbbf24', '#fde68a', '#f59e0b', '#fffbeb', '#fcd34d', '#ffffff'],
    epic: ['#c084fc', '#e879f9', '#d8b4fe', '#ffffff', '#a855f7'],
    rare: ['#60a5fa', '#93c5fd', '#bfdbfe', '#ffffff', '#3b82f6'],
    uncommon: ['#4ade80', '#86efac', '#bbf7d0', '#ffffff'],
    common: ['#d1d5db', '#e5e7eb', '#f3f4f6'],
  };

  useEffect(() => {
    if (!active) {
      setParticles([]);
      return;
    }

    const colors = extraColors[rarity];
    const newParticles: Particle[] = Array.from({ length: particleCount }, (_, i) => {
      const angle = (Math.random() * 360 * Math.PI) / 180;
      const distance = 60 + Math.random() * 120;
      return {
        id: i,
        x: 50 + (Math.random() - 0.5) * 20,
        y: 50 + (Math.random() - 0.5) * 20,
        size: 6 + Math.random() * (rarity === 'legendary' ? 16 : 10),
        tx: Math.cos(angle) * distance,
        ty: Math.sin(angle) * distance,
        delay: Math.random() * 0.3,
        duration: 0.5 + Math.random() * 0.8,
        shape: SHAPES[Math.floor(Math.random() * SHAPES.length)],
        color: colors[Math.floor(Math.random() * colors.length)],
      };
    });

    setParticles(newParticles);

    const timeout = setTimeout(() => setParticles([]), 1500);
    return () => clearTimeout(timeout);
  }, [active, rarity]);

  if (particles.length === 0) return null;

  return (
    <div
      className="pointer-events-none absolute inset-0 overflow-visible"
      style={{ zIndex: 50 }}
    >
      {particles.map((p) => (
        <div
          key={p.id}
          style={{
            position: 'absolute',
            left: `${p.x}%`,
            top: `${p.y}%`,
            transform: 'translate(-50%, -50%)',
            animation: `sparkle-fly ${p.duration}s ease-out ${p.delay}s forwards`,
            '--tx': `${p.tx}px`,
            '--ty': `${p.ty}px`,
          } as React.CSSProperties}
        >
          <ShapeSVG shape={p.shape} color={p.color} size={p.size} />
        </div>
      ))}

      {/* Central burst ring */}
      <div
        style={{
          position: 'absolute',
          left: '50%',
          top: '50%',
          transform: 'translate(-50%, -50%)',
          width: '80px',
          height: '80px',
          borderRadius: '50%',
          border: `3px solid ${config.sparkleColor}`,
          animation: 'sparkle-burst 0.6s ease-out forwards',
          boxShadow: `0 0 20px ${config.sparkleColor}`,
        }}
      />
    </div>
  );
};

export default SparkleEffect;
