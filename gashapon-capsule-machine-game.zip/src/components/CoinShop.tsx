import React, { useState } from 'react';

interface CoinShopProps {
  coins: number;
  onAddCoins: (amount: number) => void;
}

const COIN_PACKS = [
  { amount: 1, label: '1 Coin', price: 'Free!', emoji: '🪙', color: '#f59e0b' },
  { amount: 5, label: '5 Coins', price: 'Bundle', emoji: '💰', color: '#d97706' },
  { amount: 10, label: '10 Coins', price: 'Value!', emoji: '🏦', color: '#b45309' },
];

const CoinShop: React.FC<CoinShopProps> = ({ coins, onAddCoins }) => {
  const [lastAdded, setLastAdded] = useState<number | null>(null);
  const [cooldown, setCooldown] = useState(false);

  const handleAdd = (amount: number) => {
    if (cooldown) return;
    onAddCoins(amount);
    setLastAdded(amount);
    setCooldown(true);
    setTimeout(() => {
      setLastAdded(null);
      setCooldown(false);
    }, 800);
  };

  return (
    <div
      className="rounded-2xl p-4"
      style={{
        background: 'rgba(255,255,255,0.05)',
        border: '1px solid rgba(255,255,255,0.1)',
      }}
    >
      <div className="flex items-center justify-between mb-3">
        <h3 className="text-white font-black text-sm tracking-wide flex items-center gap-2">
          🏪 Coin Shop
        </h3>
        <div
          className="flex items-center gap-1.5 rounded-full px-3 py-1"
          style={{ background: 'linear-gradient(90deg, #f59e0b22, #d97706 33%)' }}
        >
          <span className="text-yellow-400 text-sm font-black">{coins}</span>
          <span className="text-yellow-500/70 text-xs">coins</span>
        </div>
      </div>

      <div className="flex gap-2">
        {COIN_PACKS.map((pack) => (
          <button
            key={pack.amount}
            onClick={() => handleAdd(pack.amount)}
            disabled={cooldown}
            className="flex-1 rounded-xl py-2 px-1 flex flex-col items-center gap-1 transition-all duration-150 active:scale-95"
            style={{
              background:
                lastAdded === pack.amount
                  ? pack.color
                  : 'rgba(255,255,255,0.06)',
              border: `1px solid ${pack.color}44`,
              boxShadow: lastAdded === pack.amount ? `0 0 16px ${pack.color}88` : 'none',
              cursor: cooldown ? 'not-allowed' : 'pointer',
            }}
          >
            <span className="text-xl">{pack.emoji}</span>
            <span className="text-white font-bold text-xs">{pack.label}</span>
            <span
              className="text-xs font-semibold"
              style={{ color: lastAdded === pack.amount ? 'white' : pack.color }}
            >
              {lastAdded === pack.amount ? '✓ Added!' : pack.price}
            </span>
          </button>
        ))}
      </div>

      <p className="text-white/25 text-xs text-center mt-3">
        This is a demo — coins are free! 🎉
      </p>
    </div>
  );
};

export default CoinShop;
